# Preferences helm chart
This repository contains the chart for the preferences service.