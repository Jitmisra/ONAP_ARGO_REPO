from onaptests.configuration.status_settings import *
from global_tests_settings import *

IGNORE_EMPTY_REPLICAS = True
