from onaptests.configuration.basic_prh_settings import *
from global_tests_settings import *
