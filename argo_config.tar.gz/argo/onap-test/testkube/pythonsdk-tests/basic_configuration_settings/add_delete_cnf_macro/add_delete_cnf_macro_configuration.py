from onaptests.configuration.add_delete_cnf_macro_settings import *
from global_tests_settings import *

SERVICE_INSTANCE_NAME = f"add_delete_cnf_macro_{str(uuid4())}"