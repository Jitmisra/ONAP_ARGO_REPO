from onaptests.configuration.pnf_macro_settings import *
from global_tests_settings import *

USE_SIMULATOR = True
PNF_SIMULATOR_URL = "pnf-macro-test-simulator.onap-tests"
PNF_SIMULATOR_PORT = "5000"