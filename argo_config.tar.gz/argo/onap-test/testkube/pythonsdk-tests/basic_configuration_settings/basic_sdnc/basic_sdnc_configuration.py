from onaptests.configuration.basic_sdnc_settings import *
from global_tests_settings import *
