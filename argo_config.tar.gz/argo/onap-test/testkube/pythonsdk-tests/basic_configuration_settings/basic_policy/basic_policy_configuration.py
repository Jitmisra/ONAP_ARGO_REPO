from onaptests.configuration.basic_policy_settings import *
from global_tests_settings import *
