from onaptests.configuration.instantiate_pnf_without_registration_event_settings import *
from global_tests_settings import *
