from onaptests.configuration.basic_onboard_settings import *
from global_tests_settings import *

SDC_CLEANUP = True
