from onaptests.configuration.aai_initial_data_setup_settings import *
from global_tests_settings import *
