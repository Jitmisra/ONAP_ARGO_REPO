from onaptests.configuration.basic_kafka_settings import *
from global_tests_settings import *
