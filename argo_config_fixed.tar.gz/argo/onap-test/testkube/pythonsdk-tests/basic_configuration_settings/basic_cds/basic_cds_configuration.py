from onaptests.configuration.cds_resource_resolution_settings import *
from global_tests_settings import *
