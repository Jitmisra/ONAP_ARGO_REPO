from onaptests.configuration.ves_publish_settings import *
from global_tests_settings import *
