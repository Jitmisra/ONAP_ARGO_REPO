from onaptests.configuration.basic_cps_settings import *
from global_tests_settings import *

CHECK_POSTGRESQL = True

DB_PRIMARY_HOST = "tcp-pgset-primary.onap.svc.cluster.local"
