from onaptests.configuration.pnf_with_ves_event_settings import *
from global_tests_settings import *
