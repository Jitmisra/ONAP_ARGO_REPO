from onaptests.configuration.basic_network_nomulticloud_settings import *
from global_tests_settings import *

SDC_CLEANUP = True
