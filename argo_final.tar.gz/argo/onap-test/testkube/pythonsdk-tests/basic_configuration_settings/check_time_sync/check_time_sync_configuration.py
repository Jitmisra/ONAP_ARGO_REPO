from onaptests.configuration.check_time_sync_settings import *
from global_tests_settings import *
